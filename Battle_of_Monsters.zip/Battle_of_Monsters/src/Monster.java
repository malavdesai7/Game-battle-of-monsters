public class Monster {
    private String name;
    public int pw;
    private int pw_max;
    public int ap;
    public int luck;
    private IState current_state;

    public Monster(String name, int pw, int ap, int luck) {
        this.name = name;
        this.pw = pw;
        this.pw_max = pw;
        this.ap = ap;
        this.luck = luck;
        this.current_state = Normal_State.getInstance();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPw() {
        return pw;
    }

    public void setPw(int pw) {
        this.pw = pw;
    }

    public int getPw_max() {
        return pw_max;
    }

    public void setPw_max(int pw_max) {
        this.pw_max = pw_max;
    }

    public IState getCurrent_state() {
        return current_state;
    }

    public void setCurrent_state(IState current_state) {
        this.current_state = current_state;
    }


    public void receiveHurt(int injury) {
        this.pw -= injury;
        System.out.println(this.getName() + " received " + injury + " damage or injuries");
        if (this.pw <= 0) {
            if(this.current_state instanceof Normal_State) {
                this.current_state = Hurt_State.getInstance();
                System.out.println(this.getName() + " is DEAD!");
            }
            if (this.current_state instanceof Super_State) {
                this.current_state = Normal_State.getInstance();
                this.heal();
            }
        }
    }

    public void heal() {
        this.pw = this.pw_max;
        System.out.println(this.getName() + " is HEALED!");
    }

    public boolean is_Lucky() {
        int random = RNG.getInstance().nextInt(0, 100);
        if (random < this.luck) {
            return true;
        }
        return false;
    }

    public boolean is_hurt() {
        if (this.current_state instanceof Hurt_State) {
            return true;
        }
        return false;
    }

    public void Attack_Target(Monster target) {
        this.current_state.Attack(this, target);
    }

    public void Boost_State() {
        this.current_state.Booster(this);
    }

    public void Heal() {
        this.pw = this.pw_max;
    }

    public String toString() {
        String state = (this.current_state instanceof Normal_State) ? "Normal" :
                (this.current_state instanceof Super_State) ? "Super" : "Hurt";
        String details = this.name + " | HP: " + this.pw;
        details += " | HP Max: " + this.pw_max;
        details += " | AP: " + this.ap;
        details += " | Luck: " + this.luck;
        details += " | State: " + this.current_state.toString();

        return details;
    }

}
