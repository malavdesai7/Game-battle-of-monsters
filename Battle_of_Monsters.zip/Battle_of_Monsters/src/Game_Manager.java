import java.time.*;
import java.util.*;

public class Game_Manager {
    private static final int BATTLE_DURATION = 50;
    public LocalDateTime start_Time = LocalDateTime.now();

    //    public LocalTime start_time = LocalTime.now();
    static List<Monster> list_monsters = new ArrayList<>();

    static void Start_Game() {
        Monster monster1 = new Monster("AGRO the Player 1", 80, 20, 25);
        Monster dragon = new Monster("Gapling the Dragon", 150, 50, 2);
        Monster golem = new Monster("Azure the Golem", 80, 15, 20);
        Monster basilisk = new Monster("Cathedral the Basilisk", 90, 25, 10);
        Monster minotaur = new Monster("Blood the Minotaur", 95, 18, 9);
        Monster orc = new Monster("Baldur the Orc", 60, 30, 25);
        Monster chicken = new Monster("Pock-Pock the Chicken", 30, 5, 70);
        list_monsters.add(monster1);
        list_monsters.add(dragon);
        list_monsters.add(golem);
        list_monsters.add(basilisk);
        list_monsters.add(minotaur);
        list_monsters.add(orc);
        list_monsters.add(chicken);
    }

    static boolean isGameOver() {
        return list_monsters.size() == 1;
    }

    public boolean isTimeOut(LocalDateTime start_Time) {
        Duration battleDuration = Duration.between(start_Time, LocalDateTime.now());
        return battleDuration.toMillis() >= BATTLE_DURATION;
    }

    public static int Get_Random_Index() {
        return RNG.getInstance().nextInt(0, list_monsters.size());
    }

    public void Battle () {
        int round = 1;
        while(!isGameOver() && !isTimeOut(start_Time)) {
            System.out.println("----- Battle round " + round + " -----");
            int index1 = Get_Random_Index();
            int index2 = Get_Random_Index();
            while (index1 == index2) {
                index2 = Get_Random_Index();
            }

            Monster attacker = null;
            Monster defender = null;
            Random rand = new Random();
            int rand_int1 = rand.nextInt(2);
            if (rand_int1 == 1) {
                attacker = list_monsters.get(index1);
                defender = list_monsters.get(index2);
            } else {
                attacker = list_monsters.get(index2);
                defender = list_monsters.get(index1);
            }

            System.out.println("Attacker: " + attacker.toString());
            System.out.println("Defender: " + defender.toString());

            while(!attacker.is_hurt() && !defender.is_hurt()) {
                if(attacker.is_Lucky()) {
                    attacker.Boost_State();
                }

                attacker.Attack_Target(defender);
                if (defender.is_hurt()) {
                    list_monsters.remove(defender);
                    System.out.println(attacker.getName() + " wins the Duel Fight!");
                    break;
                }

                Monster temp = attacker;
                attacker = defender;
                defender = temp;
                }
            round++;
            }
        System.out.println("***** List of winners *****");
        for(Monster obj : list_monsters) {
            System.out.println(obj.getName() + " Win the Battle!");
        }

    }

}
