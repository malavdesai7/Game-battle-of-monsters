public abstract class IState {
    public abstract void Attack(Monster fighter, Monster target);
    public abstract void Booster(Monster fighter);
}