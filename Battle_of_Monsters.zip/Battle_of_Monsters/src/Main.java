public class Main {
    public static void main(String[] args) {
        Game_Manager gm = new Game_Manager();
        gm.Start_Game();
        gm.Battle();
    }
}